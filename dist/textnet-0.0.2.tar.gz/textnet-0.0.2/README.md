# textnet

This is a package with a series of functions for generating and drawing word-co-occurrence networks.

This package is now under development. To install it in your Python environment, use: 

```
!pip install --index-url https://test.pypi.org/simple/ --no-deps textnet
import textnet
```

### 



#### Version history

* 0.0.1 - functions added
* 0.0.2 - second try

